const setOpacity = (window) => {
    window.opacity = .75;
    return;
};

workspace.windowAdded.connect((window) => {
    console.log("FUCK")
    window.normalWindow && setOpacity(window);
});
