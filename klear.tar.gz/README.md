# Klear
Very primitive KWin script for KDE Plasma 6.2, which makes regular desktop windows 75% transparent on opening. I've been stoked with the reliability of Plasma since the 6.1 release, but am still having some graphics issues. So why not roll my own!?


Requirements :
- KDE Plasma 6.2 (likely anything from 6.0)
- A shitty enough graphics card to bother downloading

How to install :

1. Open System Settings -> Window Management -> KWin Scripts
2. Click on "Get New..."
3. Search for Klear
4. Install from the GUI
5. Enable the script by clicking on the checkbox next to it
6. Click Apply.

How to use it :

1. Once you've enabled the script in the steps above, all "normal" desktop windows you open will be 75% transparent.

Limitations :

* It does one thing, and one thing only. If there's any interest going forward, I'll add some settings and features. I hope KDE has some graphics fixes for Wayland coming down the pike, would be awesome if themes could just start working (and yes, I'm learning the repos now to hopefully pitch in!).

